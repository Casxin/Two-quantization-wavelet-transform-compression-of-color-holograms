%小波包阈值
clear
clc

X0=imread('triCCD_RGB_holo2_2000.tif');
I0=sylianpuzcscj(X0,2000);
figure(1),imshow(I0);
X0r=X0(:,:,1);%红色分量
X0g=X0(:,:,2);%绿色分量
X0b=X0(:,:,3);%蓝色分量

X0r=double(X0r);
X0g=double(X0g);
X0b=double(X0b);
Xf0r=fftshift(fft2(X0r));
Xf0g=fftshift(fft2(X0g));
Xf0b=fftshift(fft2(X0b));

rXf0real=real(Xf0r);%实部
rXf0imag=imag(Xf0r);%虚部
gXf0real=real(Xf0g);%实部
gXf0imag=imag(Xf0g);%虚部
bXf0real=real(Xf0b);%实部
bXf0imag=imag(Xf0b);%虚部

fs=3;
m=40;
[rthr1,rsorh1,keepappr1,critr1] = ddencmp('cmp','wp',rXf0real);  %使用 ddencmp 获取阈值。
[xd1r,treedr1,perf0r1,perfl2r1]=wpdencmp(rXf0real,rsorh1,fs,'haar',critr1,m*rthr1,keepappr1);
[rthr2,rsorh2,keepappr2,critr2] = ddencmp('cmp','wp',rXf0imag);  %使用 ddencmp 获取阈值。
[xd2r,treedr2,perf0r2,perfl2r2]=wpdencmp(rXf0imag,rsorh2,fs,'haar',critr2,m*rthr2,keepappr2);

[gthr1,gsorh1,keepappg1,critg1] = ddencmp('cmp','wp',gXf0real);  %使用 ddencmp 获取阈值。
[xd1g,treedg1,perf0g1,perfl2g1]=wpdencmp(gXf0real,gsorh1,fs,'haar',critg1,m*gthr1,keepappg1);
[gthr2,gsorh2,keepappg2,critg2] = ddencmp('cmp','wp',gXf0imag);  %使用 ddencmp 获取阈值。
[xd2g,treedg2,perf0g2,perfl2g2]=wpdencmp(gXf0imag,gsorh2,fs,'haar',critg2,m*gthr2,keepappg2);

[bthr1,bsorh1,keepappb1,critb1] = ddencmp('cmp','wp',bXf0real);  %使用 ddencmp 获取阈值。
[xd1b,treedb1,perf0b1,perfl2b1]=wpdencmp(bXf0real,bsorh1,fs,'haar',critb1,m*bthr1,keepappb1);
[bthr2,bsorh2,keepappb2,critb2] = ddencmp('cmp','wp',bXf0imag);  %使用 ddencmp 获取阈值。
[xd2b,treedb2,perf0b2,perfl2b2]=wpdencmp(bXf0imag,bsorh2,fs,'haar',critb2,m*bthr2,keepappb2);
%小波分级步长量化
%r
derta=4;
[M,N]=size(X0g);
wname='haar';
[Cr1,Sr1]= wavedec2(xd1r,fs,wname);
Cr11=Cr1(Sr1(1,1)*Sr1(1,2)+1:M*N);

for a=1:(M*N-Sr1(1,1)*Sr1(1,2))
    Cr11(a)=sign(Cr11(a))*floor(abs(Cr11(a)/derta));
end
Cr1(Sr1(1,1)*Sr1(1,2)+1:M*N)=Cr11;
xd1r=waverec2(Cr1, Sr1, wname);

[Cr2,Sr2]= wavedec2(xd2r,fs,wname);
Cr21=Cr2(Sr2(1,1)*Sr2(1,2)+1:M*N);
for a=1:(M*N-Sr2(1,1)*Sr2(1,2))
     Cr21(a)=sign(Cr21(a))*floor(abs(Cr21(a)/derta));
end
Cr2(Sr2(1,1)*Sr2(1,2)+1:M*N)=Cr21;
xd2r=waverec2(Cr2, Sr2, wname);
%g
[Cg1,Sg1]= wavedec2(xd1g,fs,wname);
Cg11=Cg1(Sg1(1,1)*Sg1(1,2)+1:M*N);
for a=1:(M*N-Sg1(1,1)*Sg1(1,2))
    Cg11(a)=sign(Cg11(a))*floor(abs(Cg11(a)/derta));
end
Cg1(Sg1(1,1)*Sg1(1,2)+1:M*N)=Cg11;
xd1g=waverec2(Cg1, Sg1, wname);

[Cg2,Sg2]= wavedec2(xd2g,fs,wname);
Cg21=Cg2(Sg2(1,1)*Sg2(1,2)+1:M*N);
for a=1:(M*N-Sg2(1,1)*Sg2(1,2))
     Cg21(a)=sign(Cg21(a))*floor(abs(Cg21(a)/derta));
end
Cg2(Sg2(1,1)*Sg2(1,2)+1:M*N)=Cg21;
xd2g=waverec2(Cg2, Sg2, wname);

%b
[Cb1,Sb1]= wavedec2(xd1b,fs,wname);
Cb11=Cb1(Sb1(1,1)*Sb1(1,2)+1:M*N);
for a=1:(M*N-Sb1(1,1)*Sb1(1,2))
    Cb11(a)=sign(Cb11(a))*floor(abs(Cb11(a)/derta));
end
Cb1(Sb1(1,1)*Sb1(1,2)+1:M*N)=Cb11;
xd1b=waverec2(Cb1, Sb1, wname);

[Cb2,Sb2]= wavedec2(xd2b,fs,wname);
Cb21=Cb2(Sb2(1,1)*Sb2(1,2)+1:M*N);
for a=1:(M*N-Sb2(1,1)*Sb2(1,2))
     Cb21(a)=sign(Cb21(a))*floor(abs(Cb21(a)/derta));
end
Cb2(Sb2(1,1)*Sb2(1,2)+1:M*N)=Cb21;
xd2b=waverec2(Cb2, Sb2, wname);

rX0r=xd1r+i*xd2r;
rX0r=abs(ifft2(fftshift(rX0r)));
rX0rmax=max(max(rX0r));
rX0r=uint8(rX0r/rX0rmax*255);      %形成0-255灰度级

rX0g=xd1g+i*xd2g;
rX0g=abs(ifft2(fftshift(rX0g)));
rX0gmax=max(max(rX0g));
rX0g=uint8(rX0g/rX0gmax*255);      %形成0-255灰度级

rX0b=xd1b+i*xd2b;
rX0b=abs(ifft2(fftshift(rX0b)));
rX0bmax=max(max(rX0b));
rX0b=uint8(rX0b/rX0bmax*255);      %形成0-255灰度级
Xrr=cat(3,rX0r,rX0g,rX0b);

I1=sylianpuzcscj(Xrr,2000);
figure(2),imshow(I1),title('阈值后图像')
psnr0=psnr(double(I1),double(I0))

I1=[];
% % %空域均匀量化-2
% n=2;
% Xrr=histeq(rX0r,n);
% Xrg=histeq(rX0g,n);
% Xrb=histeq(rX0b,n);
% Xr=uint8(cat(3,Xrr,Xrg,Xrb));
% % imwrite(Xr,'小波2值化图像.jpg')

% I=sylianpuzcscj(Xr,2000);
% I=uint8(I);
% % figure(2),imshow(2.4*I),title('量化图像-2')
% psnr2=psnr(double(I),double(I0))
% I1=[I1,2*I];
% %空域均匀量化-n
n=4;
Xrr=histeq(rX0r,n);
Xrg=histeq(rX0g,n);
Xrb=histeq(rX0b,n);
Xr=uint8(cat(3,Xrr,Xrg,Xrb));
imwrite(Xr,'小波4值化图像.bmp')
I=sylianpuzcscj(Xr,2000);
I=uint8(I);
% figure(3),imshow(2.4*I),title('量化图像-4')
psnr4=psnr(double(I),double(I0))
I1=[I1,2*I];
% %空域均匀量化-n
n=6;
Xrr=histeq(rX0r,n);
Xrg=histeq(rX0g,n);
Xrb=histeq(rX0b,n);
Xr=uint8(cat(3,Xrr,Xrg,Xrb));
imwrite(Xr,'小波6值化图像.bmp')
I=sylianpuzcscj(Xr,2000);
I=uint8(I);
% figure(4),imshow(2.4*I),title('量化图像-6')
psnr6=psnr(double(I),double(I0))
I1=[I1,2*I];
% %空域均匀量化-n
n=8;
Xrr=histeq(rX0r,n);
Xrg=histeq(rX0g,n);
Xrb=histeq(rX0b,n);
Xr=uint8(cat(3,Xrr,Xrg,Xrb));
imwrite(Xr,'小波8值化图像.bmp')
I=sylianpuzcscj(Xr,2000);
I=uint8(I);
% figure(5),imshow(2.4*I),title('量化图像-8')
psnr8=psnr(double(I),double(I0))
I1=[I1,1.8*I];
% %空域均匀量化-n
n=16;
Xrr=histeq(rX0r,n);
Xrg=histeq(rX0g,n);
Xrb=histeq(rX0b,n);
Xr=uint8(cat(3,Xrr,Xrg,Xrb));
imwrite(Xr,'小波16值化图像.bmp')
I=sylianpuzcscj(Xr,2000);
I=uint8(I);
% figure(6),imshow(2.4*I),title('量化图像-16')
psnr16=psnr(double(I),double(I0))
I1=2*[I1,1.8*I];
figure(3),imshow(I1),title('小波包量化图像')