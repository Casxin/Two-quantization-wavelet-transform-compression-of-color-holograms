%小波分级阈值
clear
clc
X0r=imread('脸谱r.bmp');
X0g=imread('脸谱g.bmp');
X0b=imread('脸谱b.bmp');
X0=cat(3,X0r,X0g,X0b);
I0=lianpuzcscj(X0,2000);
figure(1),imshow(2*uint8(I0),[]);

X0r=double(X0r);
X0g=double(X0g);
X0b=double(X0b);
Xf0r=fftshift(fft2(X0r));
Xf0g=fftshift(fft2(X0g));
Xf0b=fftshift(fft2(X0b));

rXf0real=real(Xf0r);%实部
rXf0imag=imag(Xf0r);%虚部
gXf0real=real(Xf0g);%实部
gXf0imag=imag(Xf0g);%虚部
bXf0real=real(Xf0b);%实部
bXf0imag=imag(Xf0b);%虚部

wname='db1';
fs=3;
M=2;Mr=1;
m=8;
[c1r,s1r] = wavedec2(rXf0real,fs,wname);
alpha=1.5; m1r=M*prod(s1r(Mr,:));
[thr1r,nkeep1r] = wdcbm2(c1r,s1r,alpha,m1r);
[xd1r,cxd1r,sxd1r,perf01r,perfl21r] = wdencmp('lvd',c1r,s1r,wname,fs,thr1r./m,'h');

[c2r,s2r] = wavedec2(rXf0imag,fs,wname);
alpha=1.5; m2r=M*prod(s2r(Mr,:));
[thr2r,nkeep2r] = wdcbm2(c2r,s2r,alpha,m2r);
[xd2r,cxd2r,sxd2r,perf02r,perfl22r] = wdencmp('lvd',c2r,s2r,wname,fs,thr2r./m,'h');

[c1g,s1g] = wavedec2(gXf0real,fs,wname);
alpha=1.5; m1g=M*prod(s1g(Mr,:));
[thr1g,nkeep1g] = wdcbm2(c1g,s1g,alpha,m1g);
[xd1g,cxd1g,sxd1g,perf01g,perfl21g] = wdencmp('lvd',c1g,s1g,wname,fs,thr1g./m,'h');

[c2g,s2g] = wavedec2(gXf0imag,fs,wname);
alpha=1.5; m2g=M*prod(s2g(Mr,:));
[thr2g,nkeep2g] = wdcbm2(c2g,s2g,alpha,m2g);
[xd2g,cxd2g,sxd2g,perf02g,perfl22g] = wdencmp('lvd',c2g,s2g,wname,fs,thr2g./m,'h');

[c1b,s1b] = wavedec2(bXf0real,fs,wname);
alpha=1.5; m1b=M*prod(s1b(Mr,:));
[thr1b,nkeep1b] = wdcbm2(c1b,s1b,alpha,m1b);
[xd1b,cxd1b,sxd1b,perf01b,perfl21b] = wdencmp('lvd',c1b,s1b,wname,fs,thr1b./m,'h');

[c2b,s2b] = wavedec2(bXf0imag,fs,wname);
alpha=1.5; m2b=M*prod(s2b(Mr,:));
[thr2b,nkeep2b] = wdcbm2(c2b,s2b,alpha,m2b);
[xd2b,cxd2b,sxd2b,perf02b,perfl22b] = wdencmp('lvd',c2b,s2b,wname,fs,thr2b./m,'h');

%小波分级步长量化
%r
derta=4;
[M,N]=size(X0g);
[Cr1,Sr1]= wavedec2(xd1r,fs,wname);
Cr11=Cr1(Sr1(1,1)*Sr1(1,2)+1:M*N);

for a=1:(M*N-Sr1(1,1)*Sr1(1,2))
    Cr11(a)=sign(Cr11(a))*floor(abs(Cr11(a)/derta));
end
Cr1(Sr1(1,1)*Sr1(1,2)+1:M*N)=Cr11;
xd1r=waverec2(Cr1, Sr1, wname);

[Cr2,Sr2]= wavedec2(xd2r,fs,wname);
Cr21=Cr2(Sr2(1,1)*Sr2(1,2)+1:M*N);
for a=1:(M*N-Sr2(1,1)*Sr2(1,2))
     Cr21(a)=sign(Cr21(a))*floor(abs(Cr21(a)/derta));
end
Cr2(Sr2(1,1)*Sr2(1,2)+1:M*N)=Cr21;
xd2r=waverec2(Cr2, Sr2, wname);
%g
[Cg1,Sg1]= wavedec2(xd1g,fs,wname);
Cg11=Cg1(Sg1(1,1)*Sg1(1,2)+1:M*N);
for a=1:(M*N-Sg1(1,1)*Sg1(1,2))
    Cg11(a)=sign(Cg11(a))*floor(abs(Cg11(a)/derta));
end
Cg1(Sg1(1,1)*Sg1(1,2)+1:M*N)=Cg11;
xd1g=waverec2(Cg1, Sg1, wname);

[Cg2,Sg2]= wavedec2(xd2g,fs,wname);
Cg21=Cg2(Sg2(1,1)*Sg2(1,2)+1:M*N);
for a=1:(M*N-Sg2(1,1)*Sg2(1,2))
     Cg21(a)=sign(Cg21(a))*floor(abs(Cg21(a)/derta));
end
Cg2(Sg2(1,1)*Sg2(1,2)+1:M*N)=Cg21;
xd2g=waverec2(Cg2, Sg2, wname);

%b
[Cb1,Sb1]= wavedec2(xd1b,fs,wname);
Cb11=Cb1(Sb1(1,1)*Sb1(1,2)+1:M*N);
for a=1:(M*N-Sb1(1,1)*Sb1(1,2))
    Cb11(a)=sign(Cb11(a))*floor(abs(Cb11(a)/derta));
end
Cb1(Sb1(1,1)*Sb1(1,2)+1:M*N)=Cb11;
xd1b=waverec2(Cb1, Sb1, wname);

[Cb2,Sb2]= wavedec2(xd2b,fs,wname);
Cb21=Cb2(Sb2(1,1)*Sb2(1,2)+1:M*N);
for a=1:(M*N-Sb2(1,1)*Sb2(1,2))
     Cb21(a)=sign(Cb21(a))*floor(abs(Cb21(a)/derta));
end
Cb2(Sb2(1,1)*Sb2(1,2)+1:M*N)=Cb21;
xd2b=waverec2(Cb2, Sb2, wname);

rX0r=xd1r+i*xd2r;
rX0r=abs(ifft2(fftshift(rX0r)));
rX0rmax=max(max(rX0r));
rX0r=uint8(rX0r/rX0rmax*255);      %形成0-255灰度级

rX0g=xd1g+i*xd2g;
rX0g=abs(ifft2(fftshift(rX0g)));
rX0gmax=max(max(rX0g));
rX0g=uint8(rX0g/rX0gmax*255);      %形成0-255灰度级

rX0b=xd1b+i*xd2b;
rX0b=abs(ifft2(fftshift(rX0b)));
rX0bmax=max(max(rX0b));
rX0b=uint8(rX0b/rX0bmax*255);      %形成0-255灰度级
Xrr=cat(3,rX0r,rX0g,rX0b);

I1=lianpuzcscj(Xrr,2000);
figure(2),imshow(3*I1),title('阈值后图像')
psnr0=psnr(double(I1),double(I0))

I1=[];
% % %空域均匀量化-2
% n=2;
% Xrr=histeq(rX0r,n);
% Xrg=histeq(rX0g,n);
% Xrb=histeq(rX0b,n);
% Xr=uint8(cat(3,Xrr,Xrg,Xrb));
% % imwrite(Xr,'小波2值化图像.jpg')
% % I=lianpuzcscj(Xr,2000);
% I=uint8(I);
% % figure(2),imshow(2.4*I),title('量化图像-2')
% psnr2=psnr(double(I),double(I0))
% I1=[I1,2*I];
%空域均匀量化-n
n=4;
Xrr=histeq(rX0r,n);
Xrg=histeq(rX0g,n);
Xrb=histeq(rX0b,n);
Xr=uint8(cat(3,Xrr,Xrg,Xrb));
imwrite(Xr,'小波4值化图像.bmp')
I=lianpuzcscj(Xr,2000);
I=uint8(I);
figure(3),imshow(2*I),title('量化图像-4')
psnr4=psnr(double(I),double(I0))
I1=[I1,2*I];
% %空域均匀量化-n
n=6;
Xrr=histeq(rX0r,n);
Xrg=histeq(rX0g,n);
Xrb=histeq(rX0b,n);
Xr=uint8(cat(3,Xrr,Xrg,Xrb));
imwrite(Xr,'小波6值化图像.bmp')
I=lianpuzcscj(Xr,2000);
I=uint8(I);
figure(4),imshow(2*I),title('量化图像-6')
psnr6 = psnr(double(I),double(I0))
I1=[I1,2*I];
% %空域均匀量化-n
n=8;
Xrr=histeq(rX0r,n);
Xrg=histeq(rX0g,n);
Xrb=histeq(rX0b,n);
Xr=uint8(cat(3,Xrr,Xrg,Xrb));
imwrite(Xr,'小波8值化图像.bmp')
I=lianpuzcscj(Xr,2000);
I=uint8(I);
figure(5),imshow(2*I),title('量化图像-8')
psnr8=psnr(double(I),double(I0))
I1=[I1,2*I];
% %空域均匀量化-n
n=16;
Xrr=histeq(rX0r,n);
Xrg=histeq(rX0g,n);
Xrb=histeq(rX0b,n);
Xr=uint8(cat(3,Xrr,Xrg,Xrb));
imwrite(Xr,'小波16值化图像.bmp')
I=lianpuzcscj(Xr,2000);
I=uint8(I);
figure(6),imshow(2*I),title('量化图像-16')
psnr16=psnr(double(I),double(I0))
I1=2*[I1,2*I];
figure(7),imshow(I1),title('小波分级量化图像')